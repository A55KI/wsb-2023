﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._10.classes
{
    internal class Prostokont
    {
        public double sideA;
        public double sideB; //spike has been planted, B

        public Prostokont(double a, double b)
        {
            if(a<=0 || b <= 0)
            {
                //Console.WriteLine("Niepoprawne dane - z tych boków nie da się zbudować prostoKONTA.");
                throw new ArgumentException("Niepoprawne dane - z tych boków nie da się zbudować prostoKONTA.");
            }
            else
            {
                sideA = a;
                sideB = b;
            }
            

        }

        public double ObliczPole()
        {
            return sideA * sideB;

        }
    }
}
