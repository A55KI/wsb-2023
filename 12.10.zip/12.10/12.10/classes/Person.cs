﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._10.classes
{
    internal class Person
    {
        public string firstName;
        public string lastName;
        public float height;
        public float weight;

        public string getData()
        {
            //??????????? śpięęęęęęęęęęęęęęęęęę
            //chce do domu spać błagam poprogramuje w domciu ja już nie chceceeecececececece
            return  "\nImię i nazwisko: " + firstName + " " + lastName + "\nWzrost oraz waga:  " + height + " " + weight;

        }
    }
}
