﻿using _12._10.classes;

namespace _12._10
{        
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Person person = new Person();

            person.firstName = "Adolf Korwin";
            person.lastName = "Stalin";
            person.height = 169;
            person.weight = 213.7F;

            Person persona = new Person();

            persona.firstName = "Klaudeliza Amadeusz";
            persona.lastName = "Pumpernikiel-Nowakowska";
            persona.height = 132.3F;
            persona.weight = 49.2F;

            Console.WriteLine("Dane użytkownika: " + person.getData() + "\nDane użytkownika: " + persona.getData());
            */

            /*
            Console.WriteLine("Podaj bok a: ");
            double.TryParse(Console.ReadLine(), out double a);                        

            Console.WriteLine("Podaj bok b: ");
            double.TryParse(Console.ReadLine(), out double b);

            Console.OutputEncoding = System.Text.Encoding.Unicode;

            Prostokont kwadrat = new Prostokont(a, b);
            Console.WriteLine($"Pole prostokonta wynosi: " + kwadrat.ObliczPole() + "cm²");
            */

            double a;
            double b;
            
            bool validInput = false;
            
            do
            {
                Console.Write("Podaj bok a: ");
                string inputA = Console.ReadLine();
                

                Console.Write("Podaj bok b: ");
                string inputB = Console.ReadLine();

                if (double.TryParse(inputA, out a) && double.TryParse(inputB, out b))
                {
                    if (a > 0 && b > 0)
                    {
                        validInput = true;
                        Prostokont kwadrat = new Prostokont(a, b);
                        Console.OutputEncoding = System.Text.Encoding.Unicode;
                        Console.Write($"Pole prostokonta {a} oraz {b} wynosi: ");
                        Console.ForegroundColor = ConsoleColor.Magenta;
                        Console.Write($"{kwadrat.ObliczPole()}");
                        Console.ResetColor();
                        Console.Write(" cm².");
                    }
                    else Console.WriteLine("Niepoprawne dane - nie da się zbudować takiego prostokąta.");
                }
                else
                {
                    Console.WriteLine("Coś ty wpisał kurrrr");
                    Thread.Sleep(1000);
                    Console.Clear();
                }
            } while (!validInput);

            /*try
            {
                Prostokont kwadrat = new Prostokont(a, b);
                Console.OutputEncoding = System.Text.Encoding.Unicode;
                Console.WriteLine($"Pole prostokonta {a} oraz {b} wynosi {kwadrat.ObliczPole()} cm².");
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
            }*/
        }   
    }


}