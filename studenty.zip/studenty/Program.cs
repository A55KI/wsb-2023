﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace studenty
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Student student1 = new Student("Amadeusz", "Mozart", "34251");
            Osoba osoba1 = new Osoba("Hdolf", "Aitler");
            Student student2 = new Student("Jarosław", "Kaczyński", "21370");
            Osoba osoba2 = new Osoba("Nicokado", "Avocado");

            /*Console.WriteLine(osoba1.ToString());
            Console.WriteLine(osoba2.ToString());
            Console.WriteLine(student1.ToString());
            Console.WriteLine(student2.ToString());*/
            //Console.WriteLine($"Imię: {student1.Imie}, Nazwisko: {student1.Nazwisko}, Indeks: {student1.NumerIndeksu}");   
            //Console.WriteLine(osoba1.ToString());

            Osoba[] osoby = new Osoba[] { osoba1, osoba2, student1, student2 };
            foreach (var osoba in osoby)
            {
                Console.WriteLine(osoba.ToString());
            }
        }       
    }

    public class Osoba
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }

        public Osoba(string imie, string nazwisko)
        {
            Imie = imie;
            Nazwisko = nazwisko;
        }
        public override string ToString()
        {
            return $"{Imie} {Nazwisko}";
        }
    }


    public class Student : Osoba
    {
        public string NumerIndeksu { get; set; }

        public Student(string imie, string nazwisko, string nrIndeksu) : base(imie, nazwisko)
        {
            NumerIndeksu = nrIndeksu;
        }
        public override string ToString()
        {
            return $"{base.ToString()} {NumerIndeksu}";
        }

    }
}
