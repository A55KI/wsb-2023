﻿using System.Runtime.CompilerServices;

namespace _26._10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input number of liters per 100km: ");            
            double litersPer100km = double.Parse(Console.ReadLine());
            double milesPerGallon = Engine.ConvertLPKToMPG(litersPer100km);
            Console.WriteLine(milesPerGallon);

            Console.WriteLine("Input number of gallons per mile: ");
            double milesPerGallon2 = double.Parse(Console.ReadLine());
            double litersPer100km2 = Engine.ConvertMPGToLPG(milesPerGallon2);
            Console.WriteLine(litersPer100km2);

            Engine e = new Engine(3000, 20);
            Console.WriteLine($"Capacity of an engine {e.Capacity}, amount of fuel:" +
                $"{e.FuelAmount}");

            Engine e2 = new Engine(2000, 20, 77);
            Console.WriteLine($"Capacity of an engine {e2.Capacity}, amount of fuel:" +
                $"{e2.FuelAmount}, fuel tank capacity: {e2.FuelTankCapacity}");

            Car car = new Car($"Toyota", "Twoja stara", 400, 300);
            Console.WriteLine(car.Brand);

            Car srar = new Car("Mazda", "mx8", 0.65, 25, 42);
            Console.WriteLine($"Marka: {srar.Brand}, model: {srar.Model}, \npojemność: {srar.Engine.Capacity}, ilość benzyny: {srar.Engine.FuelAmount}, \npojemność zbiornika: {srar.Engine.FuelTankCapacity}");

        }
        //za chiny ludowe xdddd
        public class Car
        {
            public string Brand { get; set; }
            public string Model { get; set; }
            public Engine Engine { get; set; } 

            
            public  Car (string brand, string model, double capacity, double fuelAmount)
            {
                this.Brand = brand;
                this.Model = model;
                this.Engine.Capacity = capacity;    
                this.Engine.FuelAmount = fuelAmount;
            }

            public Car(string brand, string model, double capacity, double fuelAmount, double fuelTankCapacity)
            {
                this.Brand = brand;
                this.Model = model;
                this.Engine = new Engine(capacity, fuelAmount, fuelTankCapacity);

               
            }

            public void Go(int distance)
            {
                Console.WriteLine("I gooooooooo!!!");
                int time = distance * 100;
                Thread.Sleep(time);
                Engine.Work(distance);
                
            }
        }

        public class Engine
        {               
            public double Capacity { get; set; }
            public double FuelAmount { get; set; }
            public double FuelTankCapacity { get; } = 50.0;

            public Engine(double capacity, double fuelAmount)
            {
                this.Capacity = capacity;
                this.FuelAmount = fuelAmount;
                FuelTankCapacity = 50.0;
            }  
            
            public Engine(double capacity, double fuelAmount, double fuelTankCapacity):this(capacity, fuelAmount)
            {
                this.FuelTankCapacity = fuelTankCapacity;
                
            }

            public static double ConvertLPKToMPG(double litersper100km)
            {
                return 235.21 / litersper100km;
                
            }
          
            public static double ConvertMPGToLPG(double mpg)
            {
                return 235.21 / mpg; //mlg
            }

            public void Work(int distance)
            {
                double fuelConsumption = Capacity * 4 / 100;
                if (fuelConsumption >= FuelAmount)
                {
                    FuelAmount -= fuelConsumption * distance;
                    Console.WriteLine("Your Uber iz here!!!!!!!!");
                }
                else
                {
                    Console.WriteLine("Ha! Nie masz paliwa bambiku!!!");
                    FuelAmount = 0;
                }
            }
        }
    }
}