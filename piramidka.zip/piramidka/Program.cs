﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace piramidka
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj wysokość kolumny: ");
            int h = int.Parse(Console.ReadLine());
            int rows = h; 
            int currentNumber = 1;

            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(currentNumber);
                    currentNumber++;
                }
                Console.WriteLine();
                currentNumber = i + 1; 
            }
        }
    }
}
/*
 * 1
 * 23
 * 345
 * 4567
 * 56789
 * */