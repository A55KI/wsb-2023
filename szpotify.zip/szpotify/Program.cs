﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szpotify
{
    class Genre
    {
        public string Name { get; set; }

        public Genre(string name)
        {
            Name = name;
        }

        // Przeciążona metoda Play() - brzmienie charakterystyczne dla danego gatunku
        public virtual void Play()
        {
            Console.WriteLine($"Playing {Name} music");
        }
    }

    // Klasa potomna reprezentująca konkretny gatunek muzyczny (np. Rock)
    class Rock : Genre
    {
        public string GuitarSolo { get; set; }

        public Rock(string name, string guitarSolo) : base(name)
        {
            GuitarSolo = guitarSolo;
        }

        // Przeciążona metoda Play() - wywołuje metodę Play() z nadklasy i dodaje brzmienie charakterystyczne dla Rock
        public override void Play()
        {
            base.Play();
            Console.WriteLine($"Guitar Solo: {GuitarSolo}");
        }
    }

    class Metal : Genre
    {
        public string GuitarRiff { get; set; }

        public Metal(string name, string guitarriff) : base(name)
        {
            GuitarRiff = guitarriff;
        }

        public override void Play()
        {
            base.Play();
            Console.WriteLine($"GuitarRiff: {GuitarRiff}");
        }
    }
    // Klasa Player (odtwarzacz)
    class Player
    {
        private List<Genre> playlist = new List<Genre>();

        // Metoda dodająca utwór do playlisty
        public void Add(Genre song)
        {
            playlist.Add(song);
        }

        // Metoda usuwająca utwór z playlisty
        public void Remove(int songNumber)
        {
            if (songNumber >= 0 && songNumber < playlist.Count)
            {
                playlist.RemoveAt(songNumber);
            }
        }

        // Metoda odtwarzająca utwór z playlisty
        public void Play(int songNumber)
        {
            if (songNumber >= 0 && songNumber < playlist.Count)
            {
                playlist[songNumber].Play();
            }
        }

        // Metoda odtwarzająca wszystkie utwory z playlisty
        public void PlayAll()
        {
            foreach (var song in playlist)
            {
                song.Play();
            }
        }
    }

    class Program
    {
        static void Main()
        {
            Player player = new Player();
            bool addMoreSongs = true;

            while (addMoreSongs)
            {
                Console.Write("Podaj gatunek utworu: ");
                string genre = Console.ReadLine();

                Console.Write("Podaj tytuł utworu: ");
                string title = Console.ReadLine();

                Console.Write("Podaj wykonawcę utworu: ");
                string artist = Console.ReadLine();

                // Tworzenie obiektu gatunku na podstawie wprowadzonych danych
                switch (genre.ToLower())
                {
                    case "rock":
                        Console.Write("Podaj brzmienie solówki gitarowej: ");
                        string guitarSolo = Console.ReadLine();
                        Rock rockSong = new Rock("Rock", guitarSolo);
                        player.Add(rockSong);
                        break;

                    // Dodaj kolejne przypadki dla innych gatunków muzycznych

                    case "metal":
                        Console.WriteLine("Podaj brzmienie riff'a gitarowego: ");
                        string guitarriff = Console.ReadLine();
                        Metal metalsong = new Metal("Metal", guitarriff);
                        player.Add(metalsong);
                        break;

                    default:
                        Console.WriteLine("Nieznany gatunek muzyczny.");
                        break;
                }

                Console.Write("Czy chcesz dodać kolejny utwór? (t/n): ");
                addMoreSongs = Console.ReadLine().ToLower() == "t";
            }

            Console.WriteLine("\nOdtwarzanie utworów z playlisty:");
            player.PlayAll();
        }
    }
}
